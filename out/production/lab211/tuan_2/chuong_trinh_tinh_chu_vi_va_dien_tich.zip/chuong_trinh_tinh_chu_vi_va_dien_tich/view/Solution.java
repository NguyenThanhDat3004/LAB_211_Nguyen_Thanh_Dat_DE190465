/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tuan_2.chuong_trinh_tinh_chu_vi_va_dien_tich.view;
import tuan_2.chuong_trinh_tinh_chu_vi_va_dien_tich.model.Circle;
import tuan_2.chuong_trinh_tinh_chu_vi_va_dien_tich.model.Rectangle;
import tuan_2.chuong_trinh_tinh_chu_vi_va_dien_tich.model.Triangle;

/**
 *
 * @author nguye
 */
public class Solution {
    // ham show ket qua
    public void showSolution(Circle c, Rectangle r, Triangle t){
        r.printResult();
        c.printResult();
        t.printResult();
    }
}
